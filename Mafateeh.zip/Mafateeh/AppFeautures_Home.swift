//
//  AppFeautures_Home.swift
//  Mafateeh
//
//  Created by Arafat on 24/12/2024.
//

import SwiftUI

struct AppFeautures_Home: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AppFeautures_Home()
}
